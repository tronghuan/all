<div id="right">
        	<div class="category">
            	<h1>Danh Giỏ hàng của bạn</h1>
               	<p><a href="#">Tổng số sản phẩm</a></p>
                <p><a href="#">Tổng giá tiền</a></p>
                <p><a href="#">Xem giỏ hàng</a></p>
	            </ul>
            </div>
            <div class="category" id="news">
            	<h1>Danh sách tin tức</h1>
               	<ul id="ulnew">
                	<li><a href="#" style="font-weight:normal;">Trung tâm hành chính 1.400 tỷ</a></li>
					<li><a href="#" style="font-weight:normal;">Trung tâm hành chính 1.400 tỷ</a></li>
					<li><a href="#" style="font-weight:normal;">Trung tâm hành chính 1.400 tỷ</a></li>
                    <li><a href="#" style="font-weight:normal;">Trung tâm hành chính 1.400 tỷ </a></li>
                    <li><a href="#" style="font-weight:normal;">Trung tâm hành chính 1.400 tỷ </a></li>
                    <li><a href="#" style="font-weight:normal;">Trung tâm hành chính 1.400 tỷ </a></li>
                    <li><a href="#" style="font-weight:normal;">Trung tâm hành chính 1.400 tỷ</a></li>
                    <li><a href="#" style="font-weight:normal;">Trung tâm hành chính 1.400 tỷ</a></li>
                    <li><a href="#" style="font-weight:normal;">Trung tâm hành chính 1.400 tỷ</a></li>
                    <li><a href="#" style="font-weight:normal;">Trung tâm hành chính 1.400 tỷ</a></li>
					<li><a href="#" style="font-weight:normal;">Trung tâm hành chính 1.400 tỷ</a></li>
					<li><a href="#" style="font-weight:normal;">Trung tâm hành chính 1.400 tỷ</a></li>
                    <li><a href="#" style="font-weight:normal;">Trung tâm hành chính 1.400 tỷ </a></li>
                    <li><a href="#" style="font-weight:normal;">Trung tâm hành chính 1.400 tỷ </a></li>
                    <li><a href="#" style="font-weight:normal;">Trung tâm hành chính 1.400 tỷ </a></li>
                    <li><a href="#" style="font-weight:normal;">Trung tâm hành chính 1.400 tỷ</a></li>
                    <li><a href="#" style="font-weight:normal;">Trung tâm hành chính 1.400 tỷ</a></li>
                    <li><a href="#" style="font-weight:normal;">Trung tâm hành chính 1.400 tỷ</a></li>
                </ul>
            </div>
        </div>