<div id="left">
        	<div class="category">
            	<h1>Danh m?c s?n ph?m</h1>
                <?php
                    show_menu($listCategory);  
                ?>
                <ul>
    	        	
	            </ul>
            </div>
            
            <div class="category" id="online">
            	<h1>Qu?ng c�o</h1>
                <img src="images/doitac.jpg" width="198" />
                <hr />
                <img src="images/suntech.jpg" width="198" />
            </div>
            
        </div>