<?php
    require_once("top.php");
    require_once("left.php");
    require_once("application/modules/home/views/$template.php");
    require_once("right.php");
    require_once("bottom.php");