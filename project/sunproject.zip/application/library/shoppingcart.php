<?php
/**
 * Class name
 * Author
 * Date:
 */
class shoppingcart
{
    public function __construct()
    {
        session_start();
    }   
    
}