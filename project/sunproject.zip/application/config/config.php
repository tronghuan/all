<?php
define("APPLICATION_PATH","application/");
define("ADMIN_CSS","http://localhost/sunproject/public/admin/css/");
define("ADMIN_IMAGES","public/admin/images/");
define("ADMIN_JS","public/admin/js");

define("HOME_CSS","public/default/css/");
define("HOME_IMAGES","public/default/images/");
define("HOME_JS","public/default/js");