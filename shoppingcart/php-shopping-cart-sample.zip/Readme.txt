Shopping Cart with PayPal Express checkout
------------------------------------------
1. Import "mysql_import.sql" in your MySql PhpMyAdmin to create product table.
2. Change settings in "config.php" for database.
3. Navigate to index page of your shopping cart and enjoy.

@download from http://www.sanwebe.com